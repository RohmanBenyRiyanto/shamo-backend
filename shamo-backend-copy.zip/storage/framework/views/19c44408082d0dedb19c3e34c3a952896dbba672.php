<a href="/">
    <img src="/images/logo.svg" style="height: 30px;"/>
</a>
<?php /**PATH C:\laragon\www\shamo-backend-copy\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>