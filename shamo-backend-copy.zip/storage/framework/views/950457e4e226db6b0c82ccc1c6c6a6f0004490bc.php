<a href="/">
    <img src="/logo.svg" alt="Logo" />
</a>
<?php /**PATH C:\laragon\www\shamo-backend\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>