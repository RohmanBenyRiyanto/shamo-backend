<img src="/logo.svg" alt="Logo" style="height: 80px" />
<?php /**PATH C:\laragon\www\shamo-backend\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>