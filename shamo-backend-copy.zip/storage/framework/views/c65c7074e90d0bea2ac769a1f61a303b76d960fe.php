<img src="/logo.svg" alt="Logo" style="height: 40px" />
<?php /**PATH C:\laragon\www\shamo-backend\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>